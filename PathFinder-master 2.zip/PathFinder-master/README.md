# PathFinder
Demo: https://prakharsharma41.github.io/PathFinder/

This project consist of shortest path finding algorithms i.e BFS, DFS, Dikstra’s, A*algorithm.
This app is built on react.

Info button shows the information on what each color box represent i.e white box is start node, red box is finish node, green box is shortest path node.
This project consist of shortest path finding algorithms i.e BFS, DFS, Dikstra’s , A* algorithm.
This app is built on react. 
Info button shows the information on what each color box represent: white represent start node and red represent dark node.
Additionality functionality like user can change start and finish node are also implemented.

![s2](https://user-images.githubusercontent.com/56185838/124667416-00527d00-decd-11eb-8469-6b896190f3a4.jpg)
![s1](https://user-images.githubusercontent.com/56185838/124667387-f4ff5180-decc-11eb-8249-cbdaffc56da3.jpg)
